=== CTL Slot The Fruit ===
Tags: casino, casino game, fruit, gambling, html5 casino, instant win, jackpot, poker, slot, slot machine, videopoker,sweepstakes, lottery, fruit slot, slot fruit
Requires at least: 4.3
Tested up to: 4.3

Add Slot The Fruit to CTL Arcade plugin

== Description ==
Add Slot The Fruit to CTL Arcade plugin


	